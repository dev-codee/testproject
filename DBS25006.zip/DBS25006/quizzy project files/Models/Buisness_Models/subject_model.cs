﻿namespace Quizzy.Models.Buisness_Models
{
    public class subject_model
    {
        public string subjectID { get; set; }
        public string name { get; set; }
        public string code { get; set; }
        public string teacherID { get; set; }
    }
}
