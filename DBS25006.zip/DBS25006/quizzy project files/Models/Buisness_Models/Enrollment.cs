﻿namespace Quizzy.Models.Buisness_Models
{
    public class Enrollment
    {
        public string stuID {  get; set; }
        public string courseID { get; set; }
        public bool status { get; set; }
    }
}
