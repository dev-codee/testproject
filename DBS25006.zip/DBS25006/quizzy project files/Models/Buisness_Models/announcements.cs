﻿namespace Quizzy.Models.Buisness_Models
{
    public class Announcements
    {
        public string subject { get; set; }
        public string body { get; set; }
    }
}
