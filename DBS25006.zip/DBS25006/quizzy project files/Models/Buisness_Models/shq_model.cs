﻿namespace Quizzy.Models.Buisness_Models
{
    public class shq_model
    {
        public string shqID { get; set; }
        public string shortQuestion { get; set; }
        public string quizID { get; set; }
    }
}
