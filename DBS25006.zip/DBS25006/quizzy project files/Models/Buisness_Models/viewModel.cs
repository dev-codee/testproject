﻿namespace Quizzy.Models.Buisness_Models
{
    public class viewModel
    {
        public Teacher Teacher { get; set; }
        public subject_model Subject { get; set; }
    }
}
