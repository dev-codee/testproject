﻿namespace Quizzy.Models.DataLayer_Models
{
    public class RegistrationModel
    {
        public string email { get; set; }
        public string Password { get; set; }
        public string role { get; set; }
    }
}
