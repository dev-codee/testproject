﻿namespace Quizzy.Models.DataLayer_Models
{
    public class subjectModel
    {
        public int subjectID { get; set; }
        public string name { get; set; }
        public string code { get; set; }
        public int teacherID { get; set; }
    }
}
