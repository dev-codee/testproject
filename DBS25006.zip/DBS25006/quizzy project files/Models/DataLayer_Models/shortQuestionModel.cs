﻿namespace Quizzy.Models.DataLayer_Models
{
    public class shortQuestionModel
    {
        public int shqID { get; set; }
        public string shortQuestion {  get; set; }
        public int quizID { get; set; }
    }
}
