﻿namespace Quizzy.Models.DataLayer_Models
{
    public class enrollModel
    {
        public int stuID {  get; set; }
        public int courseID { get; set; }
        public bool status { get; set; }
    }
}
