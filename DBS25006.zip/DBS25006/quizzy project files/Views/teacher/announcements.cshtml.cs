using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzy.Views.teacher
{
    public class announcementsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
