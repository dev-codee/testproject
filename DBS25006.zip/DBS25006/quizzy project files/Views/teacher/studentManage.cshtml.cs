using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzy.Views.teacher
{
    public class studentManageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
