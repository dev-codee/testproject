using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzy.Views.student
{
    public class showQuizesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
