using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzy.Views.student
{
    public class seeOpenQuizModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
