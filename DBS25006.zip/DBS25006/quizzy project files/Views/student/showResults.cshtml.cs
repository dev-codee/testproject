using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzy.Views.student
{
    public class showResultsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
