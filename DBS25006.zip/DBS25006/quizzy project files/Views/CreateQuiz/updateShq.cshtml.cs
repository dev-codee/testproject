using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzy.Views.createQuiz
{
    public class updateShqModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
