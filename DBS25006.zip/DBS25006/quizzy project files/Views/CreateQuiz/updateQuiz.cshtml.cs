using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzy.Views.createQuiz
{
    public class updateQuizModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
