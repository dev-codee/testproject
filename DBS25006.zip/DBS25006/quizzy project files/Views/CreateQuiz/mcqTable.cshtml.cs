using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzy.Views.createQuiz
{
    public class mcqTableModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
