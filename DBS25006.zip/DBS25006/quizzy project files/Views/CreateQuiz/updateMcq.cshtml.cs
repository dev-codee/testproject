using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Quizzy.Views.createQuiz
{
    public class updateMcqModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
